export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAq5sAUr0FBZKu3XKL94NthSpTVbLS7GXw",
    authDomain: "login-595e6.firebaseapp.com",
    databaseURL: "https://login-595e6.firebaseio.com",
    projectId: "login-595e6",
    storageBucket: "login-595e6.appspot.com",
    messagingSenderId: "38911551943",
    appId: "1:38911551943:web:ed567a56b8d8ce78c191e2"
  }
};
